import React from 'react';

const Button = ({ text }) => {
    return (
        <button className="login-btn">{text}</button>
    );
};

export default Button;
