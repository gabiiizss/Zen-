import React from 'react';
import '../santos/foot.css';


const Roda = () => {

  return (
    <>
      <footer className="footer">
        <p>&copy; 2024 Zen. Todos os direitos reservados.</p>
      </footer>
    </>
  );
};

export default Roda;