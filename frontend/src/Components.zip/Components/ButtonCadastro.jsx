import React from 'react';


const ButtonCadastro = ({ text }) => {
    return (
        <button className="button-cadastro">{text}</button>
    );
};

export default ButtonCadastro;
