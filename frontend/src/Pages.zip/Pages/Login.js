import React, { useState } from 'react';
import { Link } from 'react-router-dom'; // Importa o Link do react-router-dom
import '../gabi/login.css'; // Seu arquivo CSS de estilos
import bannerLogin from '../imagens/BannerLogin.png'; // Ajuste o caminho conforme necessário

const Login = () => {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    // Lógica de login aqui
    console.log('Usuário logado:', { email, senha });
  };

  return (
    <div className="container">
      <div className="form-container">
        <h2>Login</h2>
        <form onSubmit={handleLogin}>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Senha"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            required
          />
          <button type="submit">Entrar</button>
        </form>
        {/* Link para a página de cadastro */}
        <p>
          Não tem uma conta? <Link to="/cadastro">Cadastre-se</Link>
        </p>
      </div>
      <div className="imagem-container">
        <img src={bannerLogin} alt="Login" />
      </div>
    </div>
  );
};

export default Login;
