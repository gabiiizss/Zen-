//Contato
import React from "react";

const Contato = () => {
  return (
    <>
      <div>
        <h2>Página Contato</h2>
        {/* Conteúdo da página Contato */}
      </div>
    </>
  );
};

export default Contato;
